package cubex.mahesh.trainstatus_nov9am.beans

data class Train(var name:String)
