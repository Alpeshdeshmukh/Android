package cubex.mahesh.trainstatus_nov9am.beans

data class Station(var name:String)