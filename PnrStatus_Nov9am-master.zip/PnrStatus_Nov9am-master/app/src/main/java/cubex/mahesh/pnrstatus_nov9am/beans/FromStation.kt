package cubex.mahesh.pnrstatus_nov9am.beans

data class FromStation(
    var name:String)