package cubex.mahesh.pnrstatus_nov9am.beans

data class ToStation(
    var name:String)