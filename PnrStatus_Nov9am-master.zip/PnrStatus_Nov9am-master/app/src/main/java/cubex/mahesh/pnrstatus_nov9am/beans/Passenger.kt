package cubex.mahesh.pnrstatus_nov9am.beans

data class Passenger(
    var current_status:String,
    var booking_status:String)